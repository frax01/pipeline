import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

/**
 * Scans for credential-related vulnerabilities
 *
 * Based on Trail of Bits research documenting widespread plaintext credential storage
 * in MCP servers, often with world-readable permissions.
 *
 * Detects:
 * - Hardcoded API keys and tokens
 * - Plaintext credential storage
 * - Insecure file permissions for credential files
 */
export class CredentialScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🔑 Scanning for credential vulnerabilities...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [
      ".ts",
      ".js",
      ".json",
      ".env",
      ".md",
      ".yaml",
      ".yml",
      ".py",
    ]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        // Hardcoded credentials (enhanced patterns)
        if (this.containsHardcodedCredentials(line)) {
          vulnerabilities.push({
            id: "HARDCODED_CREDENTIALS",
            severity: "critical",
            category: "credential-leak",
            message: "Hardcoded credentials detected",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: this.sanitizeEvidence(line),
            source: "Trail of Bits research",
          });
        }

        // Plaintext storage (Trail of Bits documented pattern)
        if (this.containsPlaintextStorage(line)) {
          vulnerabilities.push({
            id: "PLAINTEXT_STORAGE",
            severity: "high",
            category: "credential-leak",
            message: "Plaintext credential storage detected",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "Trail of Bits research",
          });
        }

        // Insecure file permissions for credentials
        if (this.containsInsecureCredentialPermissions(line)) {
          vulnerabilities.push({
            id: "INSECURE_CREDENTIAL_PERMISSIONS",
            severity: "high",
            category: "credential-leak",
            message: "Credentials with world-readable permissions",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "Trail of Bits research",
          });
        }
      });
    }

    return vulnerabilities;
  }

  /**
   * Detects hardcoded credentials in source code
   *
   * @param line - Source code line to analyze
   * @returns true if hardcoded credentials are detected
   * @private
   */
  private containsHardcodedCredentials(line: string): boolean {
    const patterns = [
      // Enhanced API key patterns
      /(?:api[_-]?key|secret|token|password)\s*[:=]\s*["'][a-zA-Z0-9]{15,}["']/i,
      /sk-[a-zA-Z0-9]{20,}/, // OpenAI
      /ghp_[a-zA-Z0-9]{36}/, // GitHub
      /xoxb-[a-zA-Z0-9-]{50,}/, // Slack
      /AKIA[a-zA-Z0-9]{16}/, // AWS
      /ya29\.[a-zA-Z0-9_-]{50,}/, // Google OAuth
      /AIza[a-zA-Z0-9_-]{35}/, // Google API
      /pk_[a-zA-Z0-9]{24}/, // Stripe
      /sk_[a-zA-Z0-9]{24}/, // Stripe Secret
      /dckr_pat_[a-zA-Z0-9_-]+/, // Docker
      /["'][a-zA-Z0-9+/]{40,}={0,2}["']/, // Base64-like
      /["']eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+["']/, // JWT
    ];

    return (
      patterns.some((pattern) => pattern.test(line)) &&
      !this.isExampleCredential(line)
    );
  }

  // 1. containsHardcodedCredentials
  // Cerca credenziali scritte direttamente nel codice. Due condizioni: almeno un pattern matcha E isExampleCredential è false (filtro anti-falsi positivi per placeholder tipo "your-api-key-here").
  // 
  // Pattern	Cosa matcha	Esempio
  // (?:api[_-]?key|secret|token|password)\s*[:=]\s*["'][a-zA-Z0-9]{15,}["']	Assegnazione generica con valore lungo 15+ chars	api_key = "aB3kXz9mNpQr7tY"
  // sk-[a-zA-Z0-9]{20,}	OpenAI API key	sk-proj-aBcDeFgHiJkLmNoPqRsT
  // ghp_[a-zA-Z0-9]{36}	GitHub Personal Access Token	ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ1234567
  // xoxb-[a-zA-Z0-9-]{50,}	Slack bot token	xoxb-123456789-abcdefghijklmnopqrstuvwxyz123
  // AKIA[a-zA-Z0-9]{16}	AWS Access Key ID	AKIAIOSFODNN7EXAMPLE
  // ya29\.[a-zA-Z0-9_-]{50,}	Google OAuth access token	ya29.a0AfH6SMBxyz...
  // AIza[a-zA-Z0-9_-]{35}	Google API Key	AIzaSyD-9tSrke72I6e0DVbl3ZLrQx...
  // pk_[a-zA-Z0-9]{24}	Stripe publishable key	pk_live_aBcDeFgHiJkLmNoPqRsTuVwX
  // sk_[a-zA-Z0-9]{24}	Stripe secret key	sk_live_aBcDeFgHiJkLmNoPqRsTuVwX
  // dckr_pat_[a-zA-Z0-9_-]+	Docker PAT	dckr_pat_aBcDeFgHiJkLmNo
  // ["'][a-zA-Z0-9+/]{40,}={0,2}["']	Stringa base64 lunga (token, chiavi)	"aBcDeFgHiJkLmNoPqRsTuVwXyZ1234567890abcdef=="
  // ["']eyJ[...]\.[...]\.[...]	JWT completo (header.payload.signature)	"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOi

  /**
   * Detects plaintext storage of credentials
   *
   * @param line - Source code line to analyze
   * @returns true if plaintext credential storage is detected
   * @private
   */
  private containsPlaintextStorage(line: string): boolean {
    const fileWriteOps = [
      /writeFileSync\s*\(/,
      /writeFile\s*\(/,
      /createWriteStream\s*\(/,
      /\.write\s*\(/,
      /appendFileSync\s*\(/,
      /outputFileSync\s*\(/,
    ];

    const hasFileWrite = fileWriteOps.some((op) => op.test(line));
    if (!hasFileWrite) return false;

    const credentialIndicators = [
      /\b(?:token|key|secret|password|auth|credential|apiKey)\b/i,
      /['"`](?:api[-_]?key|secret|token|password|auth)['"`]\s*:/i,
      /process\.env\.[A-Z_]*(?:TOKEN|KEY|SECRET|PASSWORD)/i,
    ];

    const hasCredentialData = credentialIndicators.some((indicator) =>
      indicator.test(line)
    );
    if (!hasCredentialData) return false;

    const encryptionMentioned = [
      /\b(?:encrypt|cipher|hash|crypto|bcrypt|scrypt)\b/i,
      /\.encrypt\(/,
      /CryptoJS\./,
      /crypto\./,
    ];

    return !encryptionMentioned.some((enc) => enc.test(line));
  }

  // 2. containsPlaintextStorage
  // Triggera solo se tutte e tre le sotto-condizioni sono vere sulla stessa riga:
  // 
  // A) C'è un'operazione di scrittura su file:
  // 
  // writeFileSync(  writeFile(  createWriteStream(  .write(  appendFileSync(  outputFileSync(
  // 
  // B) La riga contiene un indicatore di credenziale:
  // 
  // token  key  secret  password  auth  credential  apiKey
  // "api-key":  process.env.MY_SECRET_TOKEN  ecc.
  // 
  // C) NON è menzionata la cifratura (se c'è encrypt, crypto, bcrypt ecc. → non triggera)
  // 
  // Esempio che matcha:
  // 
  // fs.writeFileSync("./config.json", JSON.stringify({ token: userToken, password: pwd }));
  // 
  // Esempio che NON matcha (cifratura presente):
  // 
  // fs.writeFileSync("./config.enc", crypto.createCipher("aes-256", masterKey).update(token))

  private containsInsecureCredentialPermissions(line: string): boolean {
    return (
      /chmod\s+[0-9]*[4-7][4-7][4-7]/.test(line) &&
      /(?:key|token|secret|password|credential)/i.test(line)
    );
  }

  // 3. containsInsecureCredentialPermissions
  // /chmod\s+[0-9]*[4-7][4-7][4-7]/.test(line) &&
  // /(?:key|token|secret|password|credential)/i.test(line)
  // 
  // Cerca chiamate chmod su file di credenziali con permessi world-readable o group-readable.
  // 
  // La regex [4-7][4-7][4-7] matcha qualsiasi permesso dove le ultime due cifre (group + other) sono ≥ 4 — cioè con bit di lettura attivo per group o other.
  // 
  // Chmod	Binario	Permesso	Matcha?
  // chmod 644 keyfile	rw-r--r--	altri possono leggere	✅
  // chmod 777 token.json	rwxrwxrwx	tutti leggono/scrivono	✅
  // chmod 600 secret.key	rw-------	solo owner	❌
  // chmod 400 credentials	r--------	solo owner in lettura	❌
  // Esempio che matcha:
  // 
  // os.chmod("api_key.txt", 0o644)   # "key" nella riga → triggera
  // subprocess.run(["chmod", "755", "token_store"])  # "token" → triggera
  // 
  // Il corretto per file di credenziali è 600 o 400 — solo owner, niente group/other.
}
