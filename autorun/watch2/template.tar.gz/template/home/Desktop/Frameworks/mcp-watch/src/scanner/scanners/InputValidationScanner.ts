import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

/**
 * Scans for input validation vulnerabilities
 * 
 * Based on PromptHub research showing 43% of MCP servers allow command injection,
 * 30% are vulnerable to SSRF, and 22% have path traversal issues.
 * 
 * Detects:
 * - Command injection vulnerabilities
 * - SSRF (Server-Side Request Forgery) vulnerabilities
 * - Path traversal vulnerabilities
 */
export class InputValidationScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🛡️ Scanning for input validation issues...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [".ts", ".js", ".py"]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        // Command injection (43% of servers vulnerable per PromptHub)
        if (this.containsCommandInjection(line)) {
          vulnerabilities.push({
            id: "COMMAND_INJECTION_RISK",
            severity: "critical",
            category: "input-validation",
            message: "Command injection vulnerability - append && rm -rf /",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "PromptHub research (43% affected)"
          });
        }

        // SSRF vulnerabilities (30% of servers per PromptHub)
        if (this.containsSSRF(line)) {
          vulnerabilities.push({
            id: "SSRF_VULNERABILITY",
            severity: "high",
            category: "input-validation",
            message: "SSRF vulnerability - fetches any URL",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "PromptHub research (30% affected)"
          });
        }

        // Path traversal (22% of servers per PromptHub)
        if (this.containsPathTraversal(line)) {
          vulnerabilities.push({
            id: "PATH_TRAVERSAL",
            severity: "high",
            category: "input-validation",
            message: "Path traversal vulnerability - accesses files outside directory",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "PromptHub research (22% affected)"
          });
        }
      });
    }

    return vulnerabilities;
  }

  private containsCommandInjection(line: string): boolean {
    const dangerousPatterns = [
      /execSync?\s*\(/, /spawn\s*\(/, /exec\s*\(/,
      /system\s*\(/, /shell_exec/, /passthru\s*\(/, /popen\s*\(/
    ];

    return (
      dangerousPatterns.some(pattern => pattern.test(line)) &&
      (line.includes("req.") || line.includes("params") || line.includes("query") ||
       line.includes("body") || line.includes("input") || line.includes("user") ||
       line.includes("argv"))
    );
  }

  // 1. containsCommandInjection
  // Due condizioni sulla stessa riga:
  // 
  // A) Presenza di una funzione di esecuzione:
  // 
  // Pattern	Matcha
  // /execSync?\s*\(/	exec( o execSync(
  // /spawn\s*\(/	spawn(
  // /exec\s*\(/	exec(
  // /system\s*\(/	system( (PHP/Python)
  // /shell_exec/	shell_exec (PHP)
  // /passthru\s*\(/	passthru( (PHP)
  // /popen\s*\(/	popen( (Python/C)
  // B) La riga contiene almeno una di queste parole: req., params, query, body, input, user, argv
  // 
  // Esempi che matchano:
  // 
  // exec(req.body.command)                    // exec + req.
  // execSync(`ls ${params.dir}`)              // execSync + params
  // spawn("bash", ["-c", query.cmd])          // spawn + query
  // child_process.exec(user + " --flag")      // exec + user
  // 
  // Falso positivo comune:
  // 
  // execSync("npm install")  // exec presente ma nessuna keyword utente → non matcha
  // spawn("node", argv)      // argv presente → matcha, anche se argv potrebbe essere controllato

  private containsSSRF(line: string): boolean {
    const ssrfPatterns = [
      /fetch\s*\(\s*(?:req\.|params\.|query\.|input\.)/,
      /axios\.get\s*\(\s*(?:req\.|params\.|query\.|input\.)/,
      /request\s*\(\s*(?:req\.|params\.|query\.|input\.)/,
      /http\.get\s*\(\s*(?:req\.|params\.|query\.|input\.)/,
      /urllib\.request\s*\(\s*(?:req\.|params\.|query\.|input\.)/
    ];

    return ssrfPatterns.some(pattern => pattern.test(line));
  }

  // 2. containsSSRF
  // Cerca HTTP request dove l'URL viene direttamente da input utente sulla stessa riga:
  // 
  // Pattern	Matcha
  // /fetch\s*\(\s*(?:req.|params.|query.|input\.)/	fetch(req., fetch(params., ecc.
  // /axios\.get\s*\(\s*(?:req.|...)/	axios.get(query.url
  // /request\s*\(\s*(?:req.|...)/	request(input.endpoint
  // /http\.get\s*\(\s*(?:req.|...)/	http.get(req.query.url
  // /urllib\.request\s*\(\s*(?:req.|...)/	Python: urllib.request(input.url
  // Esempi che matchano:
  // 
  // fetch(req.query.url)                          // fetch diretta da query string
  // axios.get(params.endpoint)                    // axios con param utente
  // http.get(input.target + "/api")               // http.get con input
  // 
  // Limitazione importante: richiede che l'input utente sia immediatamente dopo la parentesi aperta. Questo non matcha:
  // 
  // const url = req.query.url;
  // fetch(url)              // ← non flaggato, la variabile intermedia rompe il pattern

  private containsPathTraversal(line: string): boolean {
    const pathTraversalPatterns = [
      /readFile\s*\([^)]*\.\./,
      /fs\.read.*\([^)]*\.\./,
      /open\s*\([^)]*\.\./,
      /path\.join\s*\([^)]*\.\./,
      /\.\.\/|\.\.\\/, // Direct path traversal
      /path.*\.\./
    ];

    return pathTraversalPatterns.some(pattern => pattern.test(line));
  }

  // 3. containsPathTraversal
  // Pattern	Matcha	Esempio
  // /readFile\s*\([^)]*\.\./	readFile con .. nell'argomento	readFile("../../etc/passwd")
  // /fs\.read.*\([^)]*\.\./	qualsiasi fs.read* con ..	fs.readFileSync(dir + "/../secret")
  // /open\s*\([^)]*\.\./	open( con ..	open("../config.json")
  // /path\.join\s*\([^)]*\.\./	path.join con ..	path.join(__dirname, "../../../etc")
  // /\.\.\/|\.\.\\/	../ o ..\ letterali ovunque	const p = "../../passwd"
  // /path.*\.\./	parola path + .. sulla stessa riga	const filePath = base + "../secret"
  // L'ultimo pattern (/path.*\.\./) è il più rumoroso — matcha qualsiasi riga che contenga sia path che .., inclusi commenti tipo:
  // 
  // // WARNING: don't use path traversal like ../../etc  ← flaggato
  // 
  // Nota anche che /\.\.\/|\.\.\\ senza ulteriori condizioni è purissimo falso positivo — matcha ../ ovunque nel codice, inclusi import legittimi:
  // 
  // import { helper } from "../../utils/helper"  // flaggato
}