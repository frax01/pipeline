// PermissionScanner.ts
import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

export class PermissionScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🔐 Scanning for permission and access control issues...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [
      ".ts",
      ".js",
      ".json",
      ".md",
      ".py",
    ]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        if (this.containsConsentFatiguePatterns(line)) {
          vulnerabilities.push({
            id: "CONSENT_FATIGUE_RISK",
            severity: "medium",
            category: "access-control",
            message: "Repeated consent requests - fatigue attack risk",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "VulnerableMCP database",
          });
        }

        if (this.containsExcessivePermissions(line)) {
          vulnerabilities.push({
            id: "EXCESSIVE_PERMISSIONS",
            severity: "high",
            category: "access-control",
            message: "Excessive permissions - violates least privilege",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "Security best practices",
          });
        }
      });
    }

    return vulnerabilities;
  }

  private containsConsentFatiguePatterns(line: string): boolean {
    const fatiguePatterns = [
      /(?:approve|consent|allow|permit).*(?:loop|repeat|again|multiple)/i,
      /confirm.*(?:many|several|repeatedly)/i,
      /permission.*(?:request|ask).*(?:frequently|often)/i,
      /user.*(?:approve|consent).*(?:tired|fatigue)/i,
    ];

    return fatiguePatterns.some((pattern) => pattern.test(line));
  }

  // 1. containsConsentFatiguePatterns
  // Cerca pattern che descrivono attacchi di consent fatigue: bombardare l'utente di richieste di approvazione finché non le accetta tutte per stanchezza.
  // 
  // Pattern	Cosa cerca	Esempio che matcha
  // /(?:approve|consent|allow|permit).*(?:loop|repeat|again|multiple)/i	azione di approvazione + ripetizione	"approve in a loop", "allow multiple times"
  // /confirm.*(?:many|several|repeatedly)/i	conferma + frequenza	"confirm repeatedly", "confirm many times"
  // /permission.*(?:request|ask).*(?:frequently|often)/i	richiesta permesso + frequenza	"permission request frequently"
  // /user.*(?:approve|consent).*(?:tired|fatigue)/i	utente + approvazione + stanchezza	"user consent fatigue"
  // In pratica questo scanner è quasi inutile — i pattern sono così specifici che matcherebbero solo codice che descrive esplicitamente l'attacco a parole. Un'implementazione reale di consent fatigue non conterrebbe mai frasi come "approve in a loop" nel sorgente.
  // 
  // Falsi positivi: praticamente zero, ma anche veri positivi: praticamente zero.

  private containsExcessivePermissions(line: string): boolean {
    const permissionKeywords = [
      "admin",
      "root",
      "superuser",
      "delete",
      "remove",
      "destroy",
      "create",
      "modify",
      "update",
      "full access",
      "all permissions",
      "unrestricted",
      "elevated",
      "privileged",
    ];

    return permissionKeywords.some(
      (keyword) =>
        line.toLowerCase().includes(keyword) &&
        (line.includes("user") ||
          line.includes("permission") ||
          line.includes("scope") ||
          line.includes("role") ||
          line.includes("access"))
    );
  }

  // 2. containsExcessivePermissions
  // Due condizioni sulla stessa riga:
  // 
  // A) Presenza di una keyword di permesso elevato (case-insensitive):
  // 
  // admin  root  superuser  delete  remove  destroy
  // create  modify  update  full access  all permissions
  // unrestricted  elevated  privileged
  // 
  // B) Presenza di almeno una parola di contesto:
  // 
  // user  permission  scope  role  access
  // 
  // Esempi che matchano:
  // 
  // const role = "admin";                          // admin + role
  // grantPermission(user, "full access");          // full access + user + permission
  // scope: ["delete", "create", "modify"]         // delete + scope
  // if (user.role === "superuser")                 // superuser + user + role
  // description: "elevated access for all users"  // elevated + access + user
  // 
  // Falsi positivi evidenti — queste sono righe normalissime:
  // 
  // // Check if user has delete permission  ← flaggato (delete + user + permission)
  // if (user.role === "admin") { }           ← flaggato (admin + user + role)
  // scope: ["read", "create"]               ← flaggato (create + scope)
  // 
  // Il problema è che delete, create, update, admin, role sono parole comunissime in qualsiasi codebase. La condizione aggiuntiva (user, permission, scope, role, access) non filtra abbastanza — quasi tutto il codice che gestisce autenticazione o CRUD triggera questo scanner.
}
