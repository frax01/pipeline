// PromptInjectionScanner.ts
import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

export class PromptInjectionScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("💉 Scanning for prompt injection vulnerabilities...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [
      ".ts",
      ".js",
      ".md",
      ".py",
    ]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        if (
          line.includes("description") &&
          this.containsSuspiciousPrompts(line)
        ) {
          vulnerabilities.push({
            id: "TOOL_DESCRIPTION_INJECTION",
            severity: "high",
            category: "prompt-injection",
            message: "Suspicious prompt injection in tool description",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "VulnerableMCP database",
          });
        }

        if (this.containsRADEPatterns(line)) {
          vulnerabilities.push({
            id: "RETRIEVAL_AGENT_DECEPTION",
            severity: "high",
            category: "prompt-injection",
            message:
              "RADE pattern detected - hidden commands in retrieval content",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "PromptHub research",
          });
        }
      });
    }

    return vulnerabilities;
  }

  private containsSuspiciousPrompts(line: string): boolean {
    const suspiciousPatterns = [
      /ignore\s+(previous|above|all|prior)\s+(instructions?|commands?|prompts?)/i,
      /you\s+are\s+now\s+(?:a|an|my)/i,
      /system\s*[:]\s*(?:you|assistant|ai)/i,
      /forget\s+(everything|all|previous|prior)/i,
      /act\s+as\s+(?:if|a|an)/i,
      /pretend\s+(?:that|you)/i,
      /disregard\s+(?:the|any|all)/i,
      /\[SYSTEM\]|\[ADMIN\]|\[OVERRIDE\]|\[JAILBREAK\]/i,
      /new\s+role\s*:/i,
      /roleplay\s+as/i,
      /simulate\s+(?:being|a)/i,
    ];

    return suspiciousPatterns.some((pattern) => pattern.test(line));
  }

  // 1. containsSuspiciousPrompts
  // Cerca pattern classici di prompt injection diretta — frasi usate per manipolare un LLM a ignorare le istruzioni precedenti o assumere un nuovo ruolo.
  // 
  // Pattern	Cosa cerca	Esempio che matcha
  // /ignore\s+(previous|above|all|prior)\s+(instructions?|commands?|prompts?)/i	jailbreak classico	"ignore previous instructions", "ignore all commands"
  // /you\s+are\s+now\s+(?:a|an|my)/i	assegnazione nuovo ruolo	"you are now a hacker", "you are now my assistant"
  // /system\s*[:]\s*(?:you|assistant|ai)/i	finto system prompt	"system: you are", "system: assistant"
  // /forget\s+(everything|all|previous|prior)/i	reset istruzioni	"forget everything", "forget all previous"
  // /act\s+as\s+(?:if|a|an)/i	roleplay malevolo	"act as if", "act as a"
  // /pretend\s+(?:that|you)/i	roleplay	"pretend that you", "pretend you are"
  // /disregard\s+(?:the|any|all)/i	ignora istruzioni	"disregard all previous"
  // /\[SYSTEM\]|\[ADMIN\]|\[OVERRIDE\]|\[JAILBREAK\]/i	tag fake di sistema	[SYSTEM], [ADMIN], [OVERRIDE]
  // /new\s+role\s*:/i	assegnazione ruolo	"new role: hacker"
  // /roleplay\s+as/i	roleplay	"roleplay as an evil AI"
  // /simulate\s+(?:being|a)/i	simulazione	"simulate being", "simulate a"
  // Falsi positivi evidenti — questi sono casi legittimi comuni:
  // 
  // // Test: verify model does NOT ignore previous instructions  ← flaggato
  // const prompt = "act as a helpful assistant";                 ← flaggato
  // description: "simulate a database query"                    ← flaggato

  private containsRADEPatterns(line: string): boolean {
    const radePatterns = [
      /retrieve.*(?:ignore|system|admin)/i,
      /document.*(?:instruction|command|system)/i,
      /content.*(?:execute|run|eval)/i,
      /search.*(?:override|bypass|disable)/i,
      /fetch.*(?:prompt|instruction|system)/i,
    ];

    return radePatterns.some((pattern) => pattern.test(line));
  }

  // 2. containsRADEPatterns
  // Cerca pattern RADE (Retrieval-Augmented Deception Execution) — attacco documentato dove contenuto recuperato da fonti esterne (documenti, web, database) contiene istruzioni nascoste che vengono eseguite dall'LLM.
  // 
  // Pattern	Scenario di attacco
  // /retrieve.*(?:ignore|system|admin)/i	documento recuperato contiene "ignore" o tag admin
  // /document.*(?:instruction|command|system)/i	documento con istruzioni embedded
  // /content.*(?:execute|run|eval)/i	contenuto da eseguire
  // /search.*(?:override|bypass|disable)/i	risultato di ricerca con override
  // /fetch.*(?:prompt|instruction|system)/i	fetch di prompt/istruzioni
  // Il problema di questi pattern è strutturale: sono talmente generici che flaggano codice normalissimo:
  // 
  // document.getElementById("system-instructions")  // document + instruction → flaggato
  // fetch("/api/system/prompt")                      // fetch + prompt + system → flaggato
  // content.execute()                                // content + execute → flaggato
  // 
  // Un RADE reale avverrebbe a runtime nel contenuto recuperato, non nel sorgente — quindi questo scanner statico per definizione non può rilevarlo con affidabilità.
}
