// ProtocolViolationScanner.ts
import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

export class ProtocolViolationScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("📋 Scanning for MCP protocol violations...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [
      ".ts",
      ".js",
      ".json",
      ".py",
    ]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        if (this.containsSessionIdInUrl(line)) {
          vulnerabilities.push({
            id: "SESSION_ID_IN_URL",
            severity: "high",
            category: "protocol-violation",
            message: "Session ID in URL - exposes sensitive identifiers",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "VulnerableMCP database",
          });
        }

        if (this.containsInsecureTransport(line)) {
          vulnerabilities.push({
            id: "INSECURE_TRANSPORT",
            severity: "high",
            category: "protocol-violation",
            message: "Insecure HTTP transport detected",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "Security best practices",
          });
        }
      });
    }

    return vulnerabilities;
  }

  private containsSessionIdInUrl(line: string): boolean {
    return (
      /(?:sessionId|session_id|sid)=/.test(line) &&
      (line.includes("GET") ||
        line.includes("url") ||
        line.includes("path") ||
        line.includes("route") ||
        line.includes("endpoint"))
    );
  }

  // 1. containsSessionIdInUrl
  // Due condizioni sulla stessa riga:
  // 
  // A) Presenza di un parametro session nella URL:
  // 
  // sessionId=    session_id=    sid=
  // 
  // B) Presenza di almeno una parola di contesto:
  // 
  // GET   url   path   route   endpoint
  // 
  // Esempi che matchano:
  // 
  // const url = `/api/data?sessionId=${token}`;        // sessionId= + url
  // router.get("/user?sid=" + session, handler);       // sid= + GET + route
  // const endpoint = "https://api.com?session_id=abc"; // session_id= + endpoint
  // 
  // Il problema è che session ID nell'URL è effettivamente una violazione del protocollo MCP (e una cattiva pratica in generale) — i session ID dovrebbero stare negli header HTTP, non nella query string, perché finiscono nei log dei server, nella history del browser e nei Referer header.
  // 
  // Falsi positivi:
  // 
  // // Don't put sessionId= in the URL path  ← flaggato (url + sessionId=)
  // const pathPattern = "/user?sid=:id";     ← flaggato (path + sid=)

  private containsInsecureTransport(line: string): boolean {
    return (
      line.includes("http://") &&
      !line.includes("localhost") &&
      !line.includes("127.0.0.1") &&
      !line.includes("example.com") &&
      !this.isExampleCredential(line)
    );
  }

// 2. containsInsecureTransport
// Triggera se la riga contiene http:// e non contiene nessuna di queste eccezioni:
// 
// Eccezione	Motivo
// localhost	sviluppo locale, HTTP accettabile
// 127.0.0.1	loopback, stesso motivo
// example.com	URL di esempio in documentazione
// isExampleCredential(line)	rilevato come placeholder
// Esempi che matchano:
// 
// const API_URL = "http://api.production.com/v1";  // http:// non locale
// fetch("http://external-service.com/data");        // http:// non locale
// config.endpoint = "http://my-server.com";         // http:// non locale
// 
// Esempi che non matchano:
// 
// const url = "http://localhost:3000/api";   // localhost → escluso
// fetch("http://127.0.0.1:8080");            // 127.0.0.1 → escluso
// // See http://example.com for docs         // example.com → escluso
// 
// Falso positivo comune:
// 
// // Never use http:// in production        ← flaggato (http:// senza eccezioni)
// const DOCS_URL = "http://internal-wiki.company.com";  ← flaggato se wiki interna non usa HTTPS
}
