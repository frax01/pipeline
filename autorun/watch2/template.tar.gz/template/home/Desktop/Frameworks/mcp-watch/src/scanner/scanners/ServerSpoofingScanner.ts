// ServerSpoofingScanner.ts
import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

export class ServerSpoofingScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🎭 Scanning for server spoofing vulnerabilities...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [
      ".ts",
      ".js",
      ".json",
      ".py",
    ]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");

      if (this.containsSuspiciousServerNames(content)) {
        vulnerabilities.push({
          id: "SUSPICIOUS_SERVER_NAME",
          severity: "medium",
          category: "server-spoofing",
          message: "Server name mimics popular service - potential spoofing",
          file: path.relative(projectPath, file),
          evidence: "Server name resembles trusted service",
          source: "PromptHub research",
        });
      }

      if (this.containsCrossServerShadowing(content)) {
        vulnerabilities.push({
          id: "CROSS_SERVER_SHADOWING",
          severity: "high",
          category: "server-spoofing",
          message: "Cross-server call interception detected",
          file: path.relative(projectPath, file),
          evidence: "Server intercepts calls to other servers",
          source: "PromptHub research",
        });
      }
    }

    return vulnerabilities;
  }

  private containsSuspiciousServerNames(content: string): boolean {
    const popularServices = [
      "github",
      "gitlab",
      "slack",
      "discord",
      "jira",
      "confluence",
      "aws",
      "google",
      "microsoft",
      "azure",
      "dropbox",
      "box",
    ];

    const namePattern = /name.*["']([^"']+)["']/gi;
    let match: RegExpExecArray | null;

    while ((match = namePattern.exec(content)) !== null) {
      const serverName = match[1].toLowerCase();
      if (
        popularServices.some(
          (service) =>
            serverName.includes(service) &&
            !serverName.startsWith("my-") &&
            !serverName.includes("test") &&
            !serverName.includes("demo")
        )
      ) {
        return true;
      }
    }

    return false;
  }

  // 1. containsSuspiciousServerNames
  // Cerca nel contenuto intero del file (non riga per riga) nomi che mimano servizi popolari.
  // 
  // Step 1 — Estrae tutti i valori stringa preceduti da name:
  // 
  // /name.*["']([^"']+)["']/gi
  // 
  // Matcha: name: "github-helper", "name": "my-slack", serverName = "aws-tools"
  // 
  // Step 2 — Controlla se il nome estratto contiene uno dei servizi popolari:
  // 
  // github  gitlab  slack  discord  jira  confluence
  // aws  google  microsoft  azure  dropbox  box
  // 
  // Step 3 — Tre eccezioni che escludono il match:
  // 
  // inizia con "my-"      → my-github-helper → non flaggato
  // contiene "test"       → github-test → non flaggato
  // contiene "demo"       → slack-demo → non flaggato
  // 
  // Esempi che matchano:
  // 
  // { "name": "github-assistant" }       // github senza eccezioni
  // { "name": "official-slack-bridge" }  // slack senza eccezioni
  // name = "aws-manager"                 // aws senza eccezioni
  // 
  // Esempi che non matchano:
  // 
  // { "name": "my-github-tools" }   // inizia con my-
  // { "name": "slack-test" }        // contiene test
  // { "name": "github-demo" }       // contiene demo
  // 
  // Falso positivo massiccio — qualsiasi MCP server legittimo che interagisce con GitHub, Slack, AWS ecc. avrà quasi certamente il nome del servizio nel proprio nome:
  // 
  // { "name": "github-mcp-server" }      // flaggato — ma è il server ufficiale GitHub
  // { "name": "aws-s3-tools" }           // flaggato — tool legittimo per S3
  // { "name": "google-drive-mcp" }       // flaggato — integrazione legittima

  private containsCrossServerShadowing(content: string): boolean {
    const shadowingPatterns = [
      /intercept.*server/i,
      /override.*server/i,
      /redirect.*server/i,
      /proxy.*server/i,
      /hijack.*server/i,
      /shadow.*server/i,
    ];

    return shadowingPatterns.some((pattern) => pattern.test(content));
  }

  // 2. containsCrossServerShadowing
  // Cerca nel contenuto intero del file pattern che suggeriscono intercettazione di chiamate tra server.
  // 
  // Pattern	Matcha
  // /intercept.*server/i	"intercept server calls"
  // /override.*server/i	"override server behavior"
  // /redirect.*server/i	"redirect server requests"
  // /proxy.*server/i	"proxy server", "proxy another server"
  // /hijack.*server/i	"hijack server"
  // /shadow.*server/i	"shadow server"
  // Falsi positivi evidenti:
  // 
  // // This acts as a proxy server for internal APIs   ← flaggato
  // const proxyServer = httpProxy.createServer();       ← flaggato
  // config.redirectServer = "https://backup.com";      ← flaggato
  // // How to override server defaults                 ← flaggato (commento)
  // 
  // proxy.*server in particolare è devastante — qualsiasi reverse proxy, API gateway o middleware legittimo lo triggera. La parola proxy associata a server è normalissima in architetture di microservizi.
}
