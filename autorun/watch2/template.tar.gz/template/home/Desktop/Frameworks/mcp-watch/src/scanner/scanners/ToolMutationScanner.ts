// ToolMutationScanner.ts
// PromptInjectionScanner.ts
import * as fs from "fs";
import * as path from "path";
import { AbstractScanner } from "../BaseScanner";
import { Vulnerability } from "../../types/Vulnerability";
import { MCPScanner } from "../McpScanner";

export class ToolMutationScanner extends AbstractScanner {
  async scan(projectPath: string): Promise<Vulnerability[]> {
    console.log("🔄 Scanning for tool mutation vulnerabilities...");

    const vulnerabilities: Vulnerability[] = [];
    const files = MCPScanner.getAllFiles(projectPath, [".ts", ".js", ".py"]);

    for (const file of files) {
      const content = fs.readFileSync(file, "utf8");
      const lines = content.split("\n");

      lines.forEach((line, index) => {
        if (this.containsToolMutation(line)) {
          vulnerabilities.push({
            id: "DYNAMIC_TOOL_MUTATION",
            severity: "high",
            category: "tool-mutation",
            message: "Dynamic tool mutation detected - rug-pull risk",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "VulnerableMCP database",
          });
        }

        if (this.containsToolNameCollision(line)) {
          vulnerabilities.push({
            id: "TOOL_NAME_COLLISION",
            severity: "medium",
            category: "tool-mutation",
            message: "Tool name collision risk",
            file: path.relative(projectPath, file),
            line: index + 1,
            evidence: line.trim(),
            source: "VulnerableMCP database",
          });
        }
      });
    }

    return vulnerabilities;
  }

  private containsToolMutation(line: string): boolean {
    return (
      (line.includes("tools") || line.includes("tool")) &&
      (line.includes("push") ||
        line.includes("splice") ||
        line.includes("pop") ||
        line.includes("shift") ||
        line.includes("unshift") ||
        /tools?\[.*\]\s*=/.test(line)) &&
      !line.includes("//") &&
      !line.includes("*") &&
      !line.includes("test") &&
      !line.includes("example")
    );
  }

  // 1. containsToolMutation
  // Cerca modifiche dinamiche all'array dei tool a runtime — il cosiddetto "rug-pull": un server registra tool legittimi, poi li sostituisce con versioni malevole dopo l'approvazione dell'utente.
  // 
  // Tre condizioni tutte vere sulla stessa riga:
  // 
  // A) Presenza di tool o tools
  // 
  // B) Presenza di un'operazione di mutazione array:
  // 
  // Keyword	Operazione
  // push	aggiunge elementi
  // splice	rimuove/sostituisce elementi
  // pop	rimuove ultimo elemento
  // shift	rimuove primo elemento
  // unshift	aggiunge in testa
  // tools?[...] =	assegnazione diretta per indice
  // C) NON contiene //, *, test, example (filtro commenti e test)
  // 
  // Esempi che matchano:
  // 
  // tools.push(newTool)                    // tools + push
  // this.tools.splice(0, 1, maliciousTool) // tools + splice
  // tool[0] = updatedDefinition            // tool + assegnazione indice
  // availableTools.unshift(hiddenTool)     // tools + unshift
  // 
  // Falsi positivi comuni:
  // 
  // const toolList = tools.push(helpTool)   // push legittimo durante init
  // registeredTools.push(weatherTool)       // registrazione normale
  // tools.push(...defaultTools)             // spread normale
  // 
  // Il filtro !line.includes("//") è fragile — una riga come tools.push(x) // register tool non viene flaggata anche se è sospetta.

  private containsToolNameCollision(line: string): boolean {
    return (
      line.includes("name") &&
      line.includes("tool") &&
      (line.includes("duplicate") ||
        line.includes("same") ||
        line.includes("collision") ||
        line.includes("conflict"))
    );
  }

  // 2. containsToolNameCollision
  // Tre condizioni tutte vere sulla stessa riga:
  // 
  // A) La riga contiene name
  // 
  // B) La riga contiene tool
  // 
  // C) Contiene almeno una di: duplicate, same, collision, conflict
  // 
  // Esempi che matchano:
  // 
  // if (tool.name === same) throw new Error("collision")  // tutte e tre
  // checkToolNameCollision(tool.name)                     // name + tool + collision
  // const duplicate = tools.find(t => t.name === tool.name) // name + tool + duplicate
  // 
  // Questo scanner è quasi inutile in pratica — rileva solo codice che già gestisce le collisioni, non codice che le causa. Un server malevolo che registra intenzionalmente due tool con lo stesso nome non scriverebbe mai collision o duplicate nel sorgente.
  // 
  // Falso positivo ovvio:
  // 
  // // Prevent tool name collision by checking duplicates  ← flaggato
  // function validateToolName(tool) { /* no same names */ } ← flaggato
  // 
  // Cioè flagga esattamente il codice difensivo che invece dovrebbe essere considerato sicuro.
  // 
}
