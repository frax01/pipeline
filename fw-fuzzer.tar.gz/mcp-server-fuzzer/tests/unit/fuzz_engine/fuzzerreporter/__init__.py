#!/usr/bin/env python3
"""
Unit tests for fuzzerreporter module.
"""
